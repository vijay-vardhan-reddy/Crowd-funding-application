import React from 'react';
 export default()=>{
    return <h1>This is page p2</h1>;
 };